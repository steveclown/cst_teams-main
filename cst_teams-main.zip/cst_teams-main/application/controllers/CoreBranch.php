<?php
	Class CoreBranch extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('MainPage_model');
			$this->load->model('CoreBranch_model');
			$this->load->helper('sistem');
			$this->load->library('fungsi');
			$this->load->library('configuration');
			$this->load->database('default');
		}
		
		public function index(){
			$data['Main_view']['CoreBranch']		= $this->CoreBranch_model->getCoreBranch();
			$data['Main_view']['content']			= 'CoreBranch/listCoreBranch_view';
			$this->load->view('MainPage_view',$data);
		}
			
		function addCoreBranch(){
			$data['Main_view']['content']			= 'CoreBranch/formaddCoreBranch_view';
			$data['Main_view']['coreregion']		= create_double($this->CoreBranch_model->getCoreRegion(),'region_id','region_name');
			$this->load->view('MainPage_view',$data);
		}
		
		function processAddCoreBranch(){
			$data = array(
				'branch_code' 				=> $this->input->post('branch_code',true),
				'branch_name' 				=> $this->input->post('branch_name',true),
				'region_id' 				=> $this->input->post('region_id',true),
				'branch_address' 			=> $this->input->post('branch_address',true),
				'branch_contact_person' 	=> $this->input->post('branch_contact_person',true),
				'branch_phone1' 			=> $this->input->post('branch_phone1',true),
				'branch_phone2' 			=> $this->input->post('branch_phone2',true),
				'branch_email' 				=> $this->input->post('branch_email',true),
				'data_state'				=> 0
			);
			
			$this->form_validation->set_rules('branch_code', 'Branch Code', 'required');
			$this->form_validation->set_rules('branch_name', 'Branch Name', 'required');
			$this->form_validation->set_rules('region_id', 'Region Name', 'required');
			$this->form_validation->set_rules('branch_address', 'Branch address', 'required');
			$this->form_validation->set_rules('branch_contact_person', 'Contact Person', 'required');
			$this->form_validation->set_rules('branch_phone1', 'Cellular 1', 'required');
			$this->form_validation->set_rules('branch_email', 'Email', 'required');
			
			if($this->form_validation->run()==true){
				if($this->CoreBranch_model->saveNewCoreBranch($data)){
					$auth = $this->session->userdata('auth');
					$this->fungsi->set_log($auth['username'],'1003','Application.CoreBranch.processaddSettingCoreBranchProfile',$auth['username'],'Add New Branch Profile');
					$msg = "<div class='alert alert-success'>                
								Add Data Branch Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->unset_userdata('addCoreBranch');
					redirect('CoreBranch/addCoreBranch');
				}else{
					$msg = "<div class='alert alert-danger'>                
								Add Data Branch UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->set_userdata('addCoreBranch',$data);
					redirect('CoreBranch/addCoreBranch');
				}
			}else{
				$this->session->set_userdata('addCoreBranch',$data);
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreBranch/addCoreBranch');
			}
		}
		
		function editCoreBranch(){
			$data['Main_view']['CoreBranch']	= $this->CoreBranch_model->getCoreBranch_Detail($this->uri->segment(3));
			$data['Main_view']['coreregion']	= create_double($this->CoreBranch_model->getCoreRegion(),'region_id','region_name');
			$data['Main_view']['content']		= 'CoreBranch/formeditCoreBranch_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function processEditCoreBranch(){
			$data = array(
				'branch_id' 				=> $this->input->post('branch_id',true),
				'branch_code' 				=> $this->input->post('branch_code',true),
				'branch_name' 				=> $this->input->post('branch_name',true),
				'region_id' 				=> $this->input->post('region_id',true),
				'branch_address' 			=> $this->input->post('branch_address',true),
				'branch_contact_person' 	=> $this->input->post('branch_contact_person',true),
				'branch_phone1' 			=> $this->input->post('branch_mobile_phone1',true),
				'branch_phone2' 			=> $this->input->post('branch_mobile_phone2',true),
				'branch_email' 				=> $this->input->post('branch_email',true),
				'data_state'				=> 0
			);
			
			$this->form_validation->set_rules('branch_code', 'Branch Code', 'required');
			$this->form_validation->set_rules('branch_name', 'Branch Name', 'required');
			$this->form_validation->set_rules('region_id', 'Region Name', 'required');
			$this->form_validation->set_rules('branch_address', 'Branch address', 'required');
			$this->form_validation->set_rules('branch_contact_person', 'Contact Person', 'required');
			$this->form_validation->set_rules('branch_mobile_phone1', 'Cellular 1', 'required');
			$this->form_validation->set_rules('branch_email', 'email', 'required');
			
			if($this->form_validation->run()==true){
				if($this->CoreBranch_model->saveEditCoreBranch($data)==true){
					$auth 	= $this->session->userdata('auth');
					// $this->fungsi->set_log($auth['username'],'1077','Application.CoreBranch.edit',$auth['username'],'Edit Branch Profile');
					// $this->fungsi->set_change_log($old_data,$data,$auth['username'],$data['CoreBranch_id']);
					$msg = "<div class='alert alert-success'>                
								Edit Branch Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreBranch/editCoreBranch/'.$data['branch_id']);
				}else{
					$msg = "<div class='alert alert-danger'>                
								Edit Branch UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreBranch/editCoreBranch/'.$data['branch_id']);
				}
			}else{
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreBranch/editCoreBranch/'.$data['branch_id']);
			}
		}
		
		function deleteCoreBranch(){
			if($this->CoreBranch_model->deleteCoreBranch($this->uri->segment(3))){
				$auth = $this->session->userdata('auth');
				$this->fungsi->set_log($auth['username'],'1005','Application.CoreBranch.delete',$auth['username'],'Delete Branch Profile');
				$msg = "<div class='alert alert-success'>                
							Delete Data Branch Profile Successfully
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreBranch');
			}else{
				$msg = "<div class='alert alert-danger'>                
							Delete Data Branch Profile UnSuccessful
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreBranch');
			}
		}
	}
?>