<?php
	Class CoreSection extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('MainPage_model');
			$this->load->model('CoreSection_model');
			$this->load->helper('sistem');
			$this->load->library('fungsi');
			$this->load->library('configuration');
			$this->load->database('default');
		}
		
		public function index(){
			$data['Main_view']['CoreSection']		= $this->CoreSection_model->getCoreSection();
			$data['Main_view']['content']			= 'CoreSection/listCoreSection_view';
			$this->load->view('MainPage_view',$data);
		}
		
		public function addCoreSection(){
			$data['Main_view']['content']			= 'CoreSection/formaddCoreSection_view';
			$data['Main_view']['coredepartment']	= create_double($this->CoreSection_model->getCoreDepartment(),'department_id','department_name');
			$this->load->view('MainPage_view',$data);
		}
		
		public function processAddCoreSection(){
			$data = array(
				'section_code' 			=> $this->input->post('section_code',true),
				'section_name' 			=> $this->input->post('section_name',true),
				'department_id' 		=> $this->input->post('department_id',true),
				'data_state'			=> 0
				
			);
			
			$this->form_validation->set_rules('section_code', 'Section Code', 'required');
			$this->form_validation->set_rules('section_name', 'Section Name', 'required');
			$this->form_validation->set_rules('department_id', 'Division Name', 'required');
			if($this->form_validation->run()==true){
				if($this->CoreSection_model->saveNewCoreSection($data)){
					$auth = $this->session->userdata('auth');
					$this->fungsi->set_log($auth['username'],'1003','Application.CoreSection.processaddCoreSection',$auth['username'],'Add New Section');
					$msg = "<div class='alert alert-success'>                
								Add Data Section Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->unset_userdata('addCoreSection');
					redirect('CoreSection/addCoreSection');
				}else{
					$msg = "<div class='alert alert-danger'>                
								Add Data Section UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->set_userdata('addCoreSection',$data);
					redirect('CoreSection/addCoreSection');
				}
			}else{
				$this->session->set_userdata('addCoreSection',$data);
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreSection/addCoreSection');
			}
		}
		
		public function editCoreSection(){
			$data['Main_view']['CoreSection']		= $this->CoreSection_model->getCoreSection_Detail($this->uri->segment(3));
			$data['Main_view']['coredepartment']	= create_double($this->CoreSection_model->getCoreDepartment(),'department_id','department_name');
			$data['Main_view']['content']			= 'CoreSection/formeditCoreSection_view';
			$this->load->view('MainPage_view',$data);
		}
		
		public function processEditCoreSection(){
			
			$data = array(
				'section_id' 			=> $this->input->post('section_id',true),
				'section_code' 			=> $this->input->post('section_code',true),
				'section_name' 			=> $this->input->post('section_name',true),
				'department_id' 		=> $this->input->post('department_id',true),
				'data_state'			=> 0
			);

			$this->form_validation->set_rules('section_code', 'Section Code', 'required');
			$this->form_validation->set_rules('section_name', 'Section Name', 'required');
			$this->form_validation->set_rules('department_id', 'Department Name', 'required');
			if($this->form_validation->run()==true){
				if($this->CoreSection_model->saveEditCoreSection($data)==true){
					$auth 	= $this->session->userdata('auth');
					// $this->fungsi->set_log($auth['username'],'1077','Application.CoreSection.edit',$auth['username'],'Edit CoreSection');
					// $this->fungsi->set_change_log($old_data,$data,$auth['username'],$data['CoreSection_id']);
					$msg = "<div class='alert alert-success'>                
								Edit Section Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreSection/editCoreSection/'.$data['section_id']);
				}else{
					$msg = "<div class='alert alert-danger'>
								Edit Section UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreSection/editCoreSection/'.$data['section_id']);
				}
			}else{
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreSection/editCoreSection/'.$data['section_id']);
			}
		}

		public function deleteCoreSection(){
			if($this->CoreSection_model->deleteCoreSection($this->uri->segment(3))){
				$auth = $this->session->userdata('auth');
				$this->fungsi->set_log($auth['username'],'1005','Application.CoreSection.delete',$auth['username'],'Delete CoreSection');
				$msg = "<div class='alert alert-success'>                
							Delete Data Section Successfully
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreSection');
			}else{
				$msg = "<div class='alert alert-danger'>                
							Delete Data Section UnSuccessful
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreSection');
			}
		}
	}
?>