<?php
	Class CoreDepartment extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('MainPage_model');
			$this->load->model('CoreDepartment_model');
			$this->load->helper('sistem');
			$this->load->library('fungsi');
			$this->load->library('configuration');
			$this->load->database('default');
		}

		public function index(){
			$data['Main_view']['CoreDepartment']		= $this->CoreDepartment_model->getCoreDepartment();
			$data['Main_view']['content']				= 'CoreDepartment/listCoreDepartment_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function addCoreDepartment(){
			$data['Main_view']['coredivision']				= create_double($this->CoreDepartment_model->getCoreDivision(),'division_id','division_name');
			$data['Main_view']['content']				= 'CoreDepartment/formaddCoreDepartment_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function processAddCoreDepartment(){
			
			$data = array(
				'department_code' 		=> $this->input->post('department_code',true),
				'department_name' 		=> $this->input->post('department_name',true),
				'division_id' 			=> $this->input->post('division_id',true),
				'data_state'			=> 0
				
			);
			
			$this->form_validation->set_rules('department_code', 'Department Code', 'required');
			$this->form_validation->set_rules('department_name', 'Department name', 'required');
			$this->form_validation->set_rules('division_id', 'Division name', 'required');
			
			if($this->form_validation->run()==true){
				if($this->CoreDepartment_model->saveNewCoreDepartment($data)){
					$auth = $this->session->userdata('auth');
					$this->fungsi->set_log($auth['username'],'1003','Application.CoreDepartment.processaddCoreDepartment',$auth['username'],'Add New Department');
					$msg = "<div class='alert alert-success'>                
								Add Data Department Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->unset_userdata('addCoreDepartment');
					redirect('CoreDepartment/addCoreDepartment');
				}else{
					$msg = "<div class='alert alert-danger'>                
								Add Data Department UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->set_userdata('addCoreDepartment',$data);
					redirect('CoreDepartment/addCoreDepartment');
				}
			}else{
				$data['password']='';
				$this->session->set_userdata('addCoreDepartment',$data);
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreDepartment/addCoreDepartment');
			}
		}
		
		function editCoreDepartment(){
			$data['Main_view']['coredivision']		= create_double($this->CoreDepartment_model->getCoreDivision(),'division_id','division_name');
			$data['Main_view']['CoreDepartment']	= $this->CoreDepartment_model->getCoreDepartment_Detail($this->uri->segment(3));
			$data['Main_view']['content']			= 'CoreDepartment/formeditCoreDepartment_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function processEditCoreDepartment(){
			
			$data = array(
				'department_id' 		=> $this->input->post('department_id',true),
				'department_code' 		=> $this->input->post('department_code',true),
				'department_name' 		=> $this->input->post('department_name',true),
				'division_id' 			=> $this->input->post('division_id',true),
				'data_state'			=> 0
			);
			
			$this->session->set_userdata('edit',$data);
			$this->form_validation->set_rules('department_code', 'Department Code', 'required');
			$this->form_validation->set_rules('department_name', 'Department name', 'required');
			
			if($this->form_validation->run()==true){
				if($this->CoreDepartment_model->saveEditCoreDepartment($data)==true){
					$auth 	= $this->session->userdata('auth');
					// $this->fungsi->set_log($auth['username'],'1077','Application.CoreDepartment.edit',$auth['username'],'Edit CoreDepartment');
					// $this->fungsi->set_change_log($old_data,$data,$auth['username'],$data['CoreDepartment_id']);
					$msg = "<div class='alert alert-success'>                
								Edit Department Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreDepartment/editCoreDepartment/'.$data['department_id']);
				}else{
					$msg = "<div class='alert alert-danger'>
								Edit Department UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreDepartment/editCoreDepartment/'.$data['department_id']);
				}
			}else{
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreDepartment/editCoreDepartment/'.$data['department_id']);
			}
		}

		function deleteCoreDepartment(){
			if($this->CoreDepartment_model->deleteCoreDepartment($this->uri->segment(3))){
				$auth = $this->session->userdata('auth');
				$this->fungsi->set_log($auth['username'],'1005','Application.CoreDepartment.delete',$auth['username'],'Delete CoreDepartment');
				$msg = "<div class='alert alert-success'>                
							Delete Data Department Successfully
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreDepartment');
			}else{
				$msg = "<div class='alert alert-danger'>                
							Delete Data Department UnSuccessful
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreDepartment');
			}
		}
	}
?>