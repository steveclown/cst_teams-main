<?php
	Class CoreDivision extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('MainPage_model');
			$this->load->model('CoreDivision_model');
			$this->load->helper('sistem');
			$this->load->library('fungsi');
			$this->load->library('configuration');
			$this->load->database('default');
		}
		
		public function index(){
			$data['Main_view']['CoreDivision']		= $this->CoreDivision_model->getCoreDivision();
			$data['Main_view']['content']			= 'CoreDivision/listCoreDivision_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function addCoreDivision(){
			$data['Main_view']['content']	= 'CoreDivision/formaddCoreDivision_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function processAddCoreDivision(){
			$data = array(
				'division_code' 		=> $this->input->post('division_code',true),
				'division_name' 		=> $this->input->post('division_name',true),
				'data_state'			=> 0
			);
			
			$this->form_validation->set_rules('division_code', 'Division Code', 'required');
			$this->form_validation->set_rules('division_name', 'Division Name', 'required');
			if($this->form_validation->run()==true){
				if($this->CoreDivision_model->saveNewCoreDivision($data)){
					$auth = $this->session->userdata('auth');
					$this->fungsi->set_log($auth['username'],'1003','Application.CoreDivision.processaddCoreDivision',$auth['username'],'Add New CoreDivision');
					$msg = "<div class='alert alert-success'>                
								Add Data Division Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->unset_userdata('addCoreDivision');
					redirect('CoreDivision/addCoreDivision');
				}else{
					$msg = "<div class='alert alert-danger'>                
								Add Data Division UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					$this->session->set_userdata('addCoreDivision',$data);
					redirect('CoreDivision/addCoreDivision');
				}
			}else{
				$this->session->set_userdata('addCoreDivision',$data);
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreDivision/addCoreDivision');
			}
		}
		
		function editCoreDivision(){
			$data['Main_view']['CoreDivision']	= $this->CoreDivision_model->getCoreDivision_Detail($this->uri->segment(3));
			$data['Main_view']['content']		= 'CoreDivision/formeditCoreDivision_view';
			$this->load->view('MainPage_view',$data);
		}
		
		function processEditCoreDivision(){
			$data = array(
				'division_id' 			=> $this->input->post('division_id',true),
				'division_code' 		=> $this->input->post('division_code',true),
				'division_name' 		=> $this->input->post('division_name',true),
				'data_state'			=> 0
			);
			$this->form_validation->set_rules('division_code', 'Division Code', 'required');
			$this->form_validation->set_rules('division_name', 'Division Name', 'required');
			
			if($this->form_validation->run()==true){
				if($this->CoreDivision_model->saveEditCoreDivision($data)==true){
					$auth 	= $this->session->userdata('auth');
					// $this->fungsi->set_log($auth['username'],'1077','Application.CoreDivision.edit',$auth['username'],'Edit CoreDivision');
					// $this->fungsi->set_change_log($old_data,$data,$auth['username'],$data['CoreDivision_id']);
					$msg = "<div class='alert alert-success'>                
								Edit Division Successfully
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreDivision/editCoreDivision/'.$data['division_id']);
				}else{
					$msg = "<div class='alert alert-danger'>                
								Edit Division UnSuccessful
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
					$this->session->set_userdata('message',$msg);
					redirect('CoreDivision/editCoreDivision/'.$data['division_id']);
				}
			}else{
				$msg = validation_errors("<div class='alert alert-danger'>", "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ");
				$this->session->set_userdata('message',$msg);
				redirect('CoreDivision/editCoreDivision/'.$data['division_id']);
			}
		}

				
		function deleteCoreDivision(){
			if($this->CoreDivision_model->deleteCoreDivision($this->uri->segment(3))){
				$auth = $this->session->userdata('auth');
				$this->fungsi->set_log($auth['username'],'1005','Application.CoreDivision.delete',$auth['username'],'Delete CoreDivision');
				$msg = "<div class='alert alert-success'>                
							Delete Data Division Successfully
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreDivision');
			}else{
				$msg = "<div class='alert alert-danger'>                
							Delete Data Division UnSuccessful
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button></div> ";
				$this->session->set_userdata('message',$msg);
				redirect('CoreDivision');
			}
		}
	}
?>